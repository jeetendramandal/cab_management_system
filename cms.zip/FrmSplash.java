
import javax.swing.*;
import java.awt.*;
import java.lang.*;

public class FrmSplash extends JWindow implements Runnable
{
	public void run()
	{
		
		JLabel SplashLabel = new JLabel(new ImageIcon("images/cab2.jpg"));
		Dimension screen = 	Toolkit.getDefaultToolkit().getScreenSize();
		JPanel content =(JPanel)this.getContentPane();
		getContentPane().add(SplashLabel,BorderLayout.CENTER);
		content.setBorder(BorderFactory.createLineBorder(Color.white, 4));
		setSize(635,355);
		setLocation((screen.width - 635)/4,((screen.height-355)/8));
				show();
		try
		{
			Thread.sleep(4000);
			dispose();
			new Logina();
		}
		catch(InterruptedException e)
		{}
		
	}

	public static void main(String s[])
	{
		Thread t1 = new Thread(new FrmSplash());
		t1.start();
	}
}
